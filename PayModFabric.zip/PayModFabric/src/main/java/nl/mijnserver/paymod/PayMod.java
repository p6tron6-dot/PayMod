package nl.mijnserver.paymod;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.text.Text;
import net.minecraft.server.command.ServerCommandSource;

import com.mojang.brigadier.Command;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

public class PayMod implements ModInitializer {

	private static final Set<UUID> betaaldeSpelers = new HashSet<>();
	public static final String MOD_ID = "paymod";

	@Override
	public void onInitialize() {
		registerCommands();
		System.out.println("[PayMod] Pay Mod gestart!");
	}

	private void registerCommands() {
		CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> {
			dispatcher.register(
				net.minecraft.server.command.CommandManager.literal("pay")
					.then(net.minecraft.server.command.CommandManager.argument("speler", StringArgumentType.word())
						.executes(context -> payCommand(context.getSource(), StringArgumentType.getString(context, "speler")))
					)
			);
		});
	}

	private static int payCommand(ServerCommandSource source, String spelernaam) {
		var server = source.getServer();
		var doelSpeler = server.getPlayerManager().getPlayer(spelernaam);

		if (doelSpeler == null) {
			source.sendError(Text.literal("§cSpeler '" + spelernaam + "' niet gevonden."));
			return 0;
		}

		UUID uuid = doelSpeler.getUuid();
		String naam = doelSpeler.getName().getString();

		if (betaaldeSpelers.contains(uuid)) {
			source.sendError(Text.literal("§e" + naam + " heeft al een betaling ontvangen!"));
			return 0;
		}

		// Zet de speler als betaald
		betaaldeSpelers.add(uuid);

		// Bericht naar de uitvoerder
		source.sendFeedback(
			() -> Text.literal("§a✔ Betaling geregistreerd voor §f" + naam + "§a!"),
			true
		);

		// Bericht naar de speler zelf
		doelSpeler.sendMessage(
			Text.literal("§a§l✔ Jij hebt een betaling ontvangen! Welkom op de server!")
		);
		doelSpeler.sendMessage(
			Text.literal("§7Je status: §aBETAALD")
		);

		// Log in console
		System.out.println("[PayMod] Betaling geregistreerd voor: " + naam + " (UUID: " + uuid + ")");

		return Command.SINGLE_SUCCESS;
	}

	public static boolean heeftBetaald(UUID uuid) {
		return betaaldeSpelers.contains(uuid);
	}

	public static Set<UUID> getBetaaldeSpelers() {
		return new HashSet<>(betaaldeSpelers);
	}
}
